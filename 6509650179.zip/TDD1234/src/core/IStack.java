package core;

public interface IStack {
	int getSize() ;
	int isEmpty() ;

}
