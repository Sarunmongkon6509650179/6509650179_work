package core;

public class Stack implements IStack {

	private int[] stackArray;
	private int max;
	private int top;

	@Override
	public int getSize() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int isEmpty() {
		if(top >= 0) {
			return stackArray[top];
		}else {
			System.out.println("Stack is empty");
			return -1;
		}
	}

	public Stack(int size) {
		max = size;
		stackArray = new int[max];
		top = -1;
	}

	public void push(int value) {
		if (top < max - 1) {
			stackArray[++top] = value;
		}else {
			System.out.println("Stack is full");
		}
	}
	
	public void push(Object value) {
		if(value instanceof Integer) {
			{
				push((int) value);
			}
		}else {
			throw new IllegalArgumentException("All elements in the stack must be the same type.");
		}
	}

	public int pop() {
		if(top >= 0) {
			int gotPop = stackArray[top--];
			System.out.println("Pop " + gotPop);
			return gotPop;
		}else {
			System.out.println("No element in stack");
			return -1;
		}
	}
}
