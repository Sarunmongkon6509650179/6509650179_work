package core;

import junit.framework.TestCase;

public class StackTestCases extends TestCase {

	public void testEmptyInitialStack() {
		Stack s0 = new Stack(5);
		s0.isEmpty();
	}
	
	public void testPushElmToTop() {
		Stack s1 = new Stack(5);
		s1.push(1);
		assertEquals(1,s1.isEmpty());
	}
	
	public void testPushDifferentElmTypeToStack() {
		Stack s2 = new Stack(5);
		s2.push(true);
	}
	
	public void testLastInFirstOut() {
		Stack s3 = new Stack(5);
		s3.push(1);
		s3.push(2);
		s3.push(3);
		s3.pop();
		s3.pop();
		s3.pop();
	}
	
	public void testPushToFullStack() {
		Stack s4 = new Stack(1);
		s4.push(1);
		s4.push(2);
	}
}
